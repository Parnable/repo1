<?php
require_once("dbcontroller.php");
$db = new PDO($dsn, $username, $passwd);
if(!empty($_POST["reg_id"])) {
        //блок подгрузки нас. пунктов 2-го уровня (города, районы областей)
 
    $query = "SELECT ter_name, ter_id FROM t_koatuu_tree WHERE ter_level = 2 AND
           reg_id = '".$_POST["reg_id"]."'";
    $result = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

?>

	<option value="<?php echo $city["ter_id"]; ?>">Выберите город</option>
<?php
	foreach($result as $city) {
?>
	<option value="<?php echo $city["ter_id"]; ?>">
            <?php echo $city["ter_name"]; ?></option>
<?php
	}
           
}

else echo "запрос неуспешен!";
?>