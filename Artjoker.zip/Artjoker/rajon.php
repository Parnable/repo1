<?php
require_once("dbcontroller.php");
$db = new PDO($dsn, $username, $passwd);
 //Тут идет блок подгрузки нас. пунктов третьего уровня (районы города, поселки)    
    if(!empty($_POST["ter_id"])) {
  $query ="SELECT ter_address FROM t_koatuu_tree WHERE ter_level = 3 AND
               reg_id = 01 AND ter_pid = 0110100000";
   $result = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
  ?>
  <option value="">Выберите район</option>
<?php
	foreach($result as $dist) {
?>
	<option value="<?php echo $dist["ter_address"]; ?>">
            <?php echo $dist["ter_address"]; ?></option>
<?php
	}

    }

else echo "запрос неуспешен!";
?>