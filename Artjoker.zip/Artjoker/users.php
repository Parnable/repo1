<?php 
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
ini_set('display_errors', 1);
ini_set("default_charset", "UTF-8");

require_once("dbcontroller.php");

$db = new PDO($dsn, $username, $passwd);
//if ($db) echo "DB connection is established<br>";

$query ="SELECT * FROM users";
$result = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $value){
    if ($value["email"] == $_POST["email"]){
        echo "Такая запись уже существует<br>";
        echo "<h3>Имя пользователя: ".$value["username"]."</h3>";
        echo "<h3>Его имейл: ".$value["email"]."</h3>";
        echo "<h3>Его расположение: ".$value["location"]."</h3>";
        echo "Подберите себе другой имейл ;)<br>";
        break;
    }
}
        
//echo "<pre>";
//var_dump($result[1]["email"]);
//echo "</pre>";


$sql = ("INSERT INTO users(username, email, location) 
         VALUES ('".$_POST["uname"]."', '".$_POST["email"]."',
         '".$_POST["district"]."')");
$stm = $db->prepare($sql);
$stm->execute();
if ($stm) echo "Данные успешно переданы";
else echo "Ничего не вышло, с базой беда";?>
<h2><a href="index.php">Вернуться к заполнению полей?</a></h2>
<?php 
