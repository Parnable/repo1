<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
//сразу формируем список областей, с которыми потом будет работать Ajax
require_once("dbcontroller.php");
//ini_set("default_charset", "cp1251");
$db = new PDO($dsn, $username, $passwd);
$query ="SELECT ter_name, reg_id, ter_id FROM t_koatuu_tree WHERE ter_type_id = 0";
$result = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";
//var_dump($data);
//echo "</pre>";]
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="vendor/bootstrap-3.3.6-dist/css/bootstrap.min.css" 
              rel="stylesheet" media="screen">
        <script src="vendor/jquery-2.2.2.js" type="text/javascript"></script>
        <title>Ajax подгрузка полей</title>
        <style>
    .form-group {width: 80%}
        </style>
        
        
<script>
    function validateForm() {
        //проверяем сначала имя
    var x = document.forms["simpleForm"]["uname"].value;
    //var name_validation = /^[a-zA-Zа-яА-Я]+$/;
    if (x.length < 1 || x.length > 75  ) {
        alert("Имя не может быть пустым или больше 75 символов");
        return false;
    }
}
</script>
        <script>  
            //Функции для работы с полями населенных пунктов    
            function getRegion(val) {
                $.ajax({
                    type: "POST",
                    url: "oblast.php",
                    data: "reg_id="+val,
                    success: function (data) {
                        $("#city-list").html(data); 
                    }
                });
            }
            
            function getDistrict(val) {
                $.ajax({
                    type: "POST",
                    url: "rajon.php",
                    data: "ter_id="+val,
                    success: function (data) {
                        $("#district-list").html(data); 
                    }
                });
            }
  
    
 
   
        </script>
    </head>
    <body>
        <center>
            <form action="users.php" name="simpleForm" class="form-group" method="POST" 
                  >
            <div class="form-group">
                <label for="exampleInputName2">Ваше имя (ФИО)</label>
                <input type="text" name="uname" class="form-control" 
                       id="exampleInputName2" placeholder="Jane Doe"
                       onkeyup="return validateForm()" required>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail2">Ваш e-mail</label>
                <input type="text" name="email" class="form-control" id="exampleInputEmail2"
                       placeholder="jane.doe@example.com" required>
            </div>
            <div class="form-group">
                
                    <label>Область:</label><br/>
                    <select name="region" id="region-list" class="demoInputBox" 
                            onChange="getRegion(this.value);" required>
                        <option value="">Выберите область</option>
                        <?php
                        foreach ($result as $reg) {                            
                            ?>
                        <option value="<?php echo $reg["reg_id"]; ?>">
                            <?php echo $reg["ter_name"]; ?></option>
                            <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Город/район области:</label><br/>
                    <select name="city" id="city-list" class="demoInputBox" 
                            onChange="getDistrict(this.value);">
                        <option value="">Выберите город</option>
                    </select>  
                </div>
                <div class="form-group">
                    <label>Ваш район города/поселок:</label><br/>
                    <select name="district" id="district-list" class="demoInputBox">
                        <option value="">Выберите район</option>
                    </select>  
                </div>
                <button type="submit" class="btn btn-success">Отослать</button>
            </form>
        </center>
    </body>
</html>