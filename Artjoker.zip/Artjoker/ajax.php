<?php

if(isset($_POST['z'])) {
	header("Content-type: text/txt; charset=UTF-8");
	if($_POST['z']=='1') {
		echo 'запрос POST успешно обработан, вы в Крыму :)';
             
	}
	else {
		echo 'увы, ничего не получилось :`(';
	}
}
?>
