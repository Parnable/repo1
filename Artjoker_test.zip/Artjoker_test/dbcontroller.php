<?php
/* Подключение к базе данных ODBC, используя вызов драйвера */
$dbname = 'artjoker_test';
$dsn = 'mysql:dbname=' . $dbname . ';host=localhost;charset=utf8';
$username = 'root';
$passwd = '';