<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
//сразу формируем список областей, с которыми потом будет работать Ajax
require_once("dbcontroller.php");
//ini_set("default_charset", "cp1251");
$db = new PDO($dsn, $username, $passwd);
$query ="SELECT ter_name, reg_id FROM t_koatuu_tree WHERE ter_type_id = 0";
$result = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";
//var_dump($data);
//echo "</pre>";]
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="vendor/bootstrap-3.3.6-dist/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <script type="text/javascript" src="http://scriptjava.net/source/scriptjava/scriptjava.js"></script>
        <script src="vendor/jquery-2.2.2.js" type="text/javascript"></script>
        <title>Ajax подгрузка полей</title>

        <script>      
            function getRegion(val) {
                $.ajax({
                    type: "POST",
                    url: "oblast.php",
                    data: "reg_id="+val,
                    success: function (data) {
                        alert(data);
                        
                    }
                });
            }
        </script>
    </head>
    <body>
        

        <form class="form-inline">
            <div class="form-group">
                <label for="exampleInputName2">Ваше имя (ФИО)</label>
                <input type="text" class="form-control" id="exampleInputName2" placeholder="Jane Doe">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail2">Ваш e-mail</label>
                <input type="email" class="form-control" id="exampleInputEmail2" placeholder="jane.doe@example.com">
            </div>
            <div class="form-group">
                
                    <label>Область:</label><br/>
                    <select name="region" id="region-list" class="chosen-select345" onChange="getRegion(this.value);">
                        <option value="">Выберите область</option>
                        <?php
                        foreach ($result as $region) {                            
                            ?>
                        <option value="<?php echo $region["reg_id"]; ?>"><?php echo $region["ter_name"]; ?></option>
                            <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Город:</label><br/>
                    <select name="city" id="city-list" class="demoInputBox">
                        <option value="">Выберите город</option>
                    </select>  
            </div>  
            <button type="submit" class="btn btn-success">Отослать</button>
        </form>  
    </body>
</html>
