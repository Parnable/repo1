<?php
require_once("dbcontroller.php");
$db = new PDO($dsn, $username, $passwd);
if(!empty($_POST["reg_id"])) {
    
    	$query ="SELECT ter_name FROM t_koatuu_tree WHERE ter_level = 2 AND
               reg_id = '".$POST["reg_id"]."'";
	$result = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
//        echo "<pre>";
//        var_dump($data);
//        echo "<pre>";
?>

	<option value="">Выберите город</option>
<?php
	foreach($result as $city) {
?>
	<option value="<?php echo $city["reg_id"]; ?>"><?php echo $city["ter_name"]; ?></option>
<?php
	}
}

else echo "запрос неуспешен!";
?>